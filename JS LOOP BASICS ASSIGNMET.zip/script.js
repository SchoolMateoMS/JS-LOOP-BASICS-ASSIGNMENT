document.getElementById("btn1").addEventListener("click", ImHappy);
document.getElementById("btn2").addEventListener("click", Multiple);
document.getElementById("btn3").addEventListener("click", OddNumbers);
document.getElementById("btn4").addEventListener("click", adding1);
document.getElementById("btn5").addEventListener("click", adding2);

function ImHappy() {
    // Print i'm so happy 500 times
    let Happy = "i'm so happy";

    for (let num = 0; num <= 499; num++) {
        console.log(Happy);
    }
}

function Multiple() {
    // mulitples of 4, from 12 to 800
    for (let num2 = 12; num2 <= 800; num2 += 4) {
        console.log(num2);
    }
}

function OddNumbers() {
    // all odd #'s from 55 to 11
    for (let num3 = 55; num3 >= 11; num3 -= 2) {
        console.log(num3);
    }
}

function adding1() {
    let total = 0;

    for (x = 5; x <= 50; x++) {
        total = total + x;
        console.log(total);
    }
}

function adding2() {
    let total2 = 0;

    for (x = 10; x <= 100; x++) {
        total2 = total2 + x;
        console.log(total2);
    }
}